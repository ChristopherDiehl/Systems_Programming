echo 'Compiling'
make
echo 'Starting Tests'
./test1
./test2
echo 'Finished Tests'